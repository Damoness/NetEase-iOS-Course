//
//  ViewController.h
//  NSThreadDemo
//
//  Created by amao on 16/8/5.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

