//
//  ViewController.h
//  HTTPDemo
//
//  Created by NetEase on 16/7/7.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

