//
//  AppDelegate.h
//  CZHTTP
//
//  Created by zhen7216 on 2017/7/21.
//  Copyright © 2017年 chenzhen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

