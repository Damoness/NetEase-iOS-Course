//
//  main.m
//  第三章单元作业
//
//  Created by miaodong on 2017/7/17.
//  Copyright © 2017年 ctitc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
