//
//  AppDelegate.h
//  第三章单元作业
//
//  Created by miaodong on 2017/7/17.
//  Copyright © 2017年 ctitc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

