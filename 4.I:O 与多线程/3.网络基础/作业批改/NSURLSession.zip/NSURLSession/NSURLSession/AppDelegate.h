//
//  AppDelegate.h
//  NSURLSession
//
//  Created by Zakari on 23/07/2017.
//  Copyright © 2017 zoi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

