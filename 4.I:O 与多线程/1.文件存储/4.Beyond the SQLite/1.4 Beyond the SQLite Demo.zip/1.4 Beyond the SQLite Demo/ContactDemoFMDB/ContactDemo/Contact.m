//
//  Contact.m
//  ContactDemo
//
//  Created by amao on 16/7/18.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import "Contact.h"
#import <sqlite3.h>

@implementation Contact

@end
