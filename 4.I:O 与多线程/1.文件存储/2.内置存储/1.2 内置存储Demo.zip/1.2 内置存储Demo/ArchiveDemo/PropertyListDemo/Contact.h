//
//  Contact.h
//  PropertyListDemo
//
//  Created by amao on 16/7/18.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contact : NSObject<NSCoding>
@property (nonatomic,copy)      NSString    *name;
@property (nonatomic,copy)      NSString    *mobile;
@end
