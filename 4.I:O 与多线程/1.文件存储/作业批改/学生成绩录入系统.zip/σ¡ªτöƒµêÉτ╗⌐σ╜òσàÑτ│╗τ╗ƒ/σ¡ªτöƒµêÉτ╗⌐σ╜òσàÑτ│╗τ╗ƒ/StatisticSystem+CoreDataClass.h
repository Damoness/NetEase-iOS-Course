//
//  StatisticSystem+CoreDataClass.h
//  学生成绩录入系统
//
//  Created by zhen7216 on 2017/7/7.
//  Copyright © 2017年 chenzhen. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface StatisticSystem : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "StatisticSystem+CoreDataProperties.h"
