//
//  StudentsAndScoresTableViewController.h
//  HomeworkDemo
//
//  Created by Hmyy on 2017/7/23.
//  Copyright © 2017年 Hmyy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudentsAndScoresTableViewController : UITableViewController
@property (nonatomic, copy) NSString *course;
@end
