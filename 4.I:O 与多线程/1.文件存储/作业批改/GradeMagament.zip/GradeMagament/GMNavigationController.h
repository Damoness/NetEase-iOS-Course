//
//  GMNavigationController.h
//  GradeMagament
//
//  Created by ShaoweiZhang on 8/7/2017.
//  Copyright © 2017 simpletask. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GMNavigationController : UINavigationController

@end
