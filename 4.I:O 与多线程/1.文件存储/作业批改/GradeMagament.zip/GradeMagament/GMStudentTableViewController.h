//
//  GMStudentTableViewController.h
//  GradeMagament
//
//  Created by ShaoweiZhang on 8/7/2017.
//  Copyright © 2017 simpletask. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GMDataCenter.h"

@interface GMStudentTableViewController : UITableViewController

@end
