//
//  ViewController.h
//  GradeMagament
//
//  Created by Ashley Han on 8/7/2017.
//  Copyright © 2017 simpletask. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

