//
//  ViewController.h
//  scoreRegistration
//
//  Created by Zakari on 23/07/2017.
//  Copyright © 2017 Zakari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

