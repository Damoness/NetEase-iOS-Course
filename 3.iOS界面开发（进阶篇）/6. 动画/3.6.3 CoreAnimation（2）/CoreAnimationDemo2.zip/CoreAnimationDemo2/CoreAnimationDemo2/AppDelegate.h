//
//  AppDelegate.h
//  CoreAnimationDemo
//
//  Created by Chengyin on 16/6/26.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

