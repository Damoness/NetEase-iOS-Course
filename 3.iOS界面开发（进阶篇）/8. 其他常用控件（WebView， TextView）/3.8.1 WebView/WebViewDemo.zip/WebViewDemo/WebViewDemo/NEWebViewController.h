//
//  NEWebViewController.h
//  WebViewDemo
//
//  Created by NetEase on 16/7/15.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NEWebViewController : UIViewController

@property (nonatomic, strong) NSString *urlString;

@end
