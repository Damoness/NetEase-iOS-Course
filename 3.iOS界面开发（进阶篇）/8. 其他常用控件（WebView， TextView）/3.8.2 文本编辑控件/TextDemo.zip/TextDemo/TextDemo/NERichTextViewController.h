//
//  NEShareViewController.h
//  TextDemo
//
//  Created by NetEase on 16/7/24.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 展示富文本相关属性的用法
 */
@interface NERichTextViewController : UIViewController

@end
