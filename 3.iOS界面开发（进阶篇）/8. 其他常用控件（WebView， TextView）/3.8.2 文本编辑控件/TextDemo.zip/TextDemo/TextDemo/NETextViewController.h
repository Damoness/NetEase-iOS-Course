//
//  NETextViewController.h
//  TextDemo
//
//  Created by NetEase on 16/7/21.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 展示UITextView的用法
 */
@interface NETextViewController : UIViewController

@end
