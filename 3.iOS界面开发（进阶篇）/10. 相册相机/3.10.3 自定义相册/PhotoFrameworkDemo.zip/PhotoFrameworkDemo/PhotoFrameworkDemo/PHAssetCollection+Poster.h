//
//  PHAssetCollection+Poster.h
//  PhotoFrameworkDemo
//
//  Created by Chengyin on 16/9/25.
//  Copyright © 2016年 Chengyin. All rights reserved.
//

#import <Photos/Photos.h>

@interface PHAssetCollection (Poster)
- (UIImage *)pi_poster;
@end
