//
//  MediaPlayerViewController.h
//  AudioPlayDemo1
//
//  Created by Chengyin on 16/7/31.
//  Copyright © 2016年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MediaPlayerViewController : UIViewController

@end
