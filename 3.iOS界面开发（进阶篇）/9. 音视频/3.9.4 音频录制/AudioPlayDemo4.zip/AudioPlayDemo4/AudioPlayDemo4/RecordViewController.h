//
//  RecordViewController.h
//  AudioPlayDemo4
//
//  Created by Chengyin on 16/8/21.
//  Copyright © 2016年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordViewController : UIViewController

@end
