//
//  VideoPlayerLayerViewController.h
//  VideoDemo
//
//  Created by Chengyin on 16/9/17.
//  Copyright © 2016年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoPlayerLayerViewController : UIViewController

- (instancetype)initWithURL:(NSURL *)url;
@end
