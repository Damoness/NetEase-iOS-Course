//
//  PlayerViewController.h
//  VideoDemo
//
//  Created by Chengyin on 16/9/5.
//  Copyright © 2016年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerViewController : UIViewController

@end
