//
//  AppDelegate.h
//  1.首页导航栏
//
//  Created by wd on 2017/5/27.
//  Copyright © 2017年 ditiy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

