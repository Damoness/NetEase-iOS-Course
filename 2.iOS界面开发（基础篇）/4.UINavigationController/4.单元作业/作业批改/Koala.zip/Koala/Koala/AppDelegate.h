//
//  AppDelegate.h
//  Koala
//
//  Created by Lamo on 2017/5/5.
//  Copyright © 2017年 Lamo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

