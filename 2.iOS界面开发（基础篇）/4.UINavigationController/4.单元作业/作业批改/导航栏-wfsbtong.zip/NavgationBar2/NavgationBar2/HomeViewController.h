//
//  HomeViewController.h
//  NavgationBar2
//
//  Created by 王子通 on 2017/6/4.
//  Copyright © 2017年 王子通. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController

@end
