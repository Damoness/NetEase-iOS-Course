//
//  main.m
//  Demo1
//
//  Created by zjw on 2017/6/4.
//  Copyright © 2017年 zjw. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
