//
//  NextViewController.h
//  CustomNav
//
//  Created by wtndcs on 16/7/31.
//  Modified by Zakari on 16/11/20.
//  Copyright © 2016年 Netease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextViewController : UIViewController

@end
