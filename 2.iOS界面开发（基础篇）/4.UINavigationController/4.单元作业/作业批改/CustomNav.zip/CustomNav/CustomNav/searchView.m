//
//  searchView.m
//  CustomNav
//
//  Created by Zakari on 20/11/2016.
//  Copyright © 2016 Netease. All rights reserved.
//

#import "searchView.h"

@implementation searchView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
