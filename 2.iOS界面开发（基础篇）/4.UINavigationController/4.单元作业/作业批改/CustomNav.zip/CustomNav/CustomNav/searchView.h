//
//  searchView.h
//  CustomNav
//
//  Created by Zakari on 20/11/2016.
//  Copyright © 2016 Netease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface searchView : UIView
@property (weak, nonatomic) IBOutlet UILabel *Test;

@end
