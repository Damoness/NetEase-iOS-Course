//
//  NavViewController.h
//  NavigationProject
//
//  Created by huangchenpeng on 2017/6/4.
//  Copyright © 2017年 ChamberH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavViewController : UINavigationController

@end
