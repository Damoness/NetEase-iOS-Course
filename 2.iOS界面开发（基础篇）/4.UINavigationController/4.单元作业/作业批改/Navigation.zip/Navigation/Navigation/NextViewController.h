//
//  NextViewController.h
//  Navigation
//
//  Created by Willei Wang on 2017/6/3.
//  Copyright © 2017年 Willei Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextViewController : UIViewController

@end
