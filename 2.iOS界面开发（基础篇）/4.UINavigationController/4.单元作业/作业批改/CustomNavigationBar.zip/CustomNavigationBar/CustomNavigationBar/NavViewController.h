//
//  NavViewController.h
//  CustomNavigationBar
//
//  Created by zhen7216 on 2017/5/14.
//  Copyright © 2017年 chenzhen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavViewController : UINavigationController

@end
