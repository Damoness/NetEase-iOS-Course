//
//  KLNextViewController.h
//  kaolaNavigationBar
//
//  Created by jele lam on 3/6/2017.
//  Copyright © 2017年 jele lam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KLNextViewController : UIViewController

@end
