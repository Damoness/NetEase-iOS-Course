//
//  titleView.h
//  kaolaNavigationBar
//
//  Created by jele lam on 3/6/2017.
//  Copyright © 2017年 jele lam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KLTitleView : UIView
@property (weak, nonatomic) IBOutlet UIButton *scanButton;
@property (weak, nonatomic) IBOutlet UIButton *messageButton;

@end
