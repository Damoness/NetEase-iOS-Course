//
//  AppDelegate.h
//  NavigationControllerTest
//
//  Created by CyouGuang on 17/5/31.
//  Copyright © 2017年 CyouGuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

