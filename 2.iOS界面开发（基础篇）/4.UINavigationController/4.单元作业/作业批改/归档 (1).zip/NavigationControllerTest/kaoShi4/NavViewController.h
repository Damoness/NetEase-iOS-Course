//
//  NavViewController.h
//  kaoShi4
//
//  Created by CyouGuang on 17/2/5.
//  Copyright © 2017年 CyouGuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavViewController : UINavigationController

@end
