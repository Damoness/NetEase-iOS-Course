//
//  scanQRCodeViewController.h
//  naviDemo
//
//  Created by 江宝敏 on 2017/6/2.
//  Copyright © 2017年 江宝敏. All rights reserved.
//

//扫描二维码类
#import "ViewController.h"

@interface scanQRCodeViewController : ViewController

@end
