//
//  AppDelegate.h
//  naviDemo
//
//  Created by 江宝敏 on 2017/6/2.
//  Copyright © 2017年 江宝敏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

