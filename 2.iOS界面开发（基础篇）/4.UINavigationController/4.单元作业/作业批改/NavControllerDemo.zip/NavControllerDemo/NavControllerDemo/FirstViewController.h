//
//  ViewController.h
//  NavControllerDemo
//
//  Created by Ashley Han on 27/1/2017.
//  Copyright © 2017 netease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

- (IBAction)gotoNextClick:(id)sender;

@end

