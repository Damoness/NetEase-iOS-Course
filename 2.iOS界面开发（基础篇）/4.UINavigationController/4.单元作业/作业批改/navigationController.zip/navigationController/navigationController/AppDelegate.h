//
//  AppDelegate.h
//  navigationController
//
//  Created by lusuihao-mac on 2017/5/26.
//  Copyright © 2017年 lusuihao-mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

