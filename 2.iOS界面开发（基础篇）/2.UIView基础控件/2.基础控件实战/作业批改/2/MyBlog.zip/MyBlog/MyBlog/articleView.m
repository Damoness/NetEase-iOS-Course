//
//  articleView.m
//  MyBlog
//
//  Created by jele lam on 2/6/2017.
//  Copyright © 2017年 jele lam. All rights reserved.
//

#import "articleView.h"

@implementation articleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
