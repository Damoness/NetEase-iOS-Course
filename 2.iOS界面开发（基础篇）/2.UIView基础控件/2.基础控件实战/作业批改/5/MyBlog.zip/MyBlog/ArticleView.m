//
//  ArticleView.m
//  MyBlog
//
//  Created by 姚凯 on 2017/5/20.
//  Copyright © 2017年 姚凯. All rights reserved.
//

#import "ArticleView.h"

@implementation ArticleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
