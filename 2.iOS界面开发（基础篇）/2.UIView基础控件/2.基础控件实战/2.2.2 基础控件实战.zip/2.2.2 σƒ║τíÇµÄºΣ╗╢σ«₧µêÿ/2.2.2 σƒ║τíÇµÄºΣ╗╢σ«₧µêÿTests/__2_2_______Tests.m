//
//  __2_2_______Tests.m
//  2.2.2 基础控件实战Tests
//
//  Created by 吴狄 on 2017/5/20.
//  Copyright © 2017年 SharePlus. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface __2_2_______Tests : XCTestCase

@end

@implementation __2_2_______Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
