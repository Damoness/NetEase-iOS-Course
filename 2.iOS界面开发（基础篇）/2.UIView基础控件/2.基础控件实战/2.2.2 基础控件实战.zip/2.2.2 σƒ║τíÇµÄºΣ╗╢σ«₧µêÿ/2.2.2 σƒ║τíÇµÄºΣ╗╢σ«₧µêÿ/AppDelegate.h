//
//  AppDelegate.h
//  2.2.2 基础控件实战
//
//  Created by 吴狄 on 2017/5/20.
//  Copyright © 2017年 SharePlus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

