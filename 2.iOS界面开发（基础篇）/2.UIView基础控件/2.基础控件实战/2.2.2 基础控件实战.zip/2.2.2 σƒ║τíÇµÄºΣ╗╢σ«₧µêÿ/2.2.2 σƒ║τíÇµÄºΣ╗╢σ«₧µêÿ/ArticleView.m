//
//  ArticleView.m
//  2.2.2 基础控件实战
//
//  Created by 吴狄 on 2017/5/23.
//  Copyright © 2017年 SharePlus. All rights reserved.
//

#import "ArticleView.h"

@implementation ArticleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(void)layoutSubviews{
    
    
    
}

@end
