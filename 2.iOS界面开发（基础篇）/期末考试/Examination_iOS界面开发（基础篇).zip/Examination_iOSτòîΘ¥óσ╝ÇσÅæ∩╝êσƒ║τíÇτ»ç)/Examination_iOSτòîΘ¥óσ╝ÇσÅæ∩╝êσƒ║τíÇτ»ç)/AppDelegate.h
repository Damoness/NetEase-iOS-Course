//
//  AppDelegate.h
//  Examination_iOS界面开发（基础篇)
//
//  Created by 吴狄 on 2017/6/3.
//  Copyright © 2017年 SharePlus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

