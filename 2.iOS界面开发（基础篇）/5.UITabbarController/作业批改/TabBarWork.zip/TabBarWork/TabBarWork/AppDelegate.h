//
//  AppDelegate.h
//  TabBarWork
//
//  Created by lusuihao-mac on 2017/5/16.
//  Copyright © 2017年 lusuihao-mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

