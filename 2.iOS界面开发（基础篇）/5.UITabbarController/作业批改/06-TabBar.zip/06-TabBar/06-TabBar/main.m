//
//  main.m
//  06-TabBar
//
//  Created by 苗冬 on 2017/5/30.
//  Copyright © 2017年 苗冬. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
