//
//  AppDelegate.h
//  TabBarTask
//
//  Created by zhaxin on 17/6/1.
//  Copyright © 2017年 zhaxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

