//
//  AppDelegate.h
//  TabBarControllerDemo
//
//  Created by Ashley Han on 30/5/2017.
//  Copyright © 2017 simpletask. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

